jack2vm.c 是用 Google Ai Studio 將 haviva 的 python 版 Jack Compiler 程式轉為 C 語言的結果

https://aistudio.google.com/prompts/14z76SeJADLm3RSs2lxF6B-vkGatSktx-
