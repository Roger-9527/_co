./jack2vm ../jack/Seven
./jack2vm ../jack/Square
./jack2vm ../jack/Average
#./jack2vm ../jack/Pong
./jack2vm ../jack/ConvertToBin
./jack2vm ../jack/ComplexArrays

