python py/Compiler.py jack/Average
python py/Compiler.py jack/Square
python py/Compiler.py jack/Seven
