#./jack2vm ArrayTest/
#./jack2vm Square/
./jack2vm Seven/
#./jack2vm.sh ArrayTest/Main
#./jack2vm.sh ExpressionLessSquare/Main
#./jack2vm.sh ExpressionLessSquare/Square
#./jack2vm.sh ExpressionLessSquare/SquareGame
# ./jack2vm.sh Square/Main
#./jack2vm.sh Square/Square
#./jack2vm.sh Square/SquareGame

