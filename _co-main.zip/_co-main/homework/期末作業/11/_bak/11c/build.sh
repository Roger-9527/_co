gcc -Wall -Wextra -g -fsanitize=address -fsanitize=undefined jack2vm.c -o jack2vm
